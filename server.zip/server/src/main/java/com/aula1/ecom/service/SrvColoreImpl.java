
package com.aula1.ecom.service;


import org.springframework.stereotype.Service;

/**
 *
 * @author aless
 */
    @Service
public class SrvColoreImpl implements SrvColore{
    
//   @Autowired
//   RepColore repColore;
//   
//    public List<ColoreDto> coloreTipo() {
//        return repColore.findAll();
//    
}
