
package com.aula1.ecom.service;




public interface SrvColore {
    
//    public List<ColoreDto> coloreTipo();
//    public void aggiungi(Long id);
//    public void modifica(Long id);
//    public void rimuovi(Long id);
}
